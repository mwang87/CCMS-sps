#ifndef __SITEPARSE_H__
#define __SITEPARSE_H__


int parseAndRunConfig(char* input_file);

#endif

