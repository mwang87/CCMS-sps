#ifndef __MSCLUSTER_H__
#define __MSCLUSTER_H__


#include "MsClusterDataStorage.h"


#endif
